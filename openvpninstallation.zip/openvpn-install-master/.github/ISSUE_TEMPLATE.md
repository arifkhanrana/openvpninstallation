<!---

Before opening an issue, please make sure:

- You installed OpenVPN with the lastest version of the script
- You read the FAQ
- Your issue is about the script, NOT OpenVPN itself
- To your OpenVPN version and OS for both the server and the client if needed

--->
